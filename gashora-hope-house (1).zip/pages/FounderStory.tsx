
import React from 'react';
import SectionHeader from '../components/SectionHeader';
import { Quote, MapPin, Calendar, Heart, Youtube, Instagram, Facebook, ArrowRight } from 'lucide-react';
import { FOUNDER_DATA } from '../data';
import { Link } from 'react-router-dom';

const FounderStory: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-6xl mx-auto">
          {/* Header Section */}
          <div className="mb-12">
            <SectionHeader 
              title="A Life Transformed" 
              subtitle="The journey of Danny Shash, from the corporate world of Manhattan to the heart of Gashora Village."
              centered={false}
            />
          </div>
          
          {/* Cinematic Hero Image */}
          <div className="relative aspect-[21/9] rounded-[2.5rem] overflow-hidden shadow-2xl mb-16 border-4 border-white bg-slate-100">
            <img 
              src="https://raw.githubusercontent.com/armel12/hope-home-rwanda/9bfd48ea86c52f8206f095f5c7e2e10059c2d70b/images/children3.jpg" 
              alt="Danny with the children" 
              className="w-full h-full object-cover" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/30 to-transparent"></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 lg:gap-16">
            {/* Main Narrative (Left Side - 75%) */}
            <div className="lg:col-span-3 space-y-16">
              <article className="prose prose-lg max-w-none text-slate-700 leading-relaxed">
                <div className="space-y-8 text-xl">
                  <p className="font-bold text-emerald-900 text-3xl md:text-4xl serif italic leading-tight mb-12 border-l-8 border-orange-500 pl-8">
                    "I didn't choose Gashora. Gashora chose me. It's a place where resilience grows in the most unexpected ways."
                  </p>
                  
                  <p>
                    Danny Shash was a professional in the heart of New York City. She had everything the world says is necessary for happiness, but beneath the surface, there was a calling for something deeper—a sense of missing pieces she couldn't quite name.
                  </p>
                  <p>
                    In 2019, Danny boarded a plane to Rwanda for what was meant to be a temporary 3-month humanitarian trip. Within weeks of arriving in Gashora Village, located in the rolling hills of Bugesera, the profound needs—and the profound spirits—of the local children captured her heart.
                  </p>
                  <p>
                    She saw brilliant children unable to attend school because they couldn't afford a $15 uniform or a pair of shoes. She met families struggling to provide even one balanced meal a day. Instead of returning to her life in New York, Danny decided to build a new life in the service of these children.
                  </p>
                  <p>
                    Today, Danny is more than a founder; she is <span className="font-bold text-emerald-900">"Mama Danny"</span> to dozens of children. She lives on-site at the Hope House, managing daily operations, coordinating with local schools, and advocating for the dignity of every child in her care.
                  </p>
                </div>
              </article>

              {/* Redesigned Vertical Timeline */}
              <div className="bg-white p-10 md:p-14 rounded-[3rem] shadow-sm border border-slate-100">
                <h3 className="text-2xl font-bold serif text-emerald-900 mb-12 flex items-center gap-4">
                  <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-xl flex items-center justify-center">
                    <Calendar size={20} />
                  </div>
                  The Journey So Far
                </h3>
                
                <div className="space-y-12 relative before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-0.5 before:bg-emerald-50">
                  {FOUNDER_DATA.timeline.map((item, idx) => (
                    <div key={idx} className="flex gap-10 relative group">
                      <div className="w-10 h-10 rounded-full bg-white border-4 border-emerald-50 shadow-sm shrink-0 z-10 flex items-center justify-center transition-colors group-hover:border-orange-200">
                        <div className="w-3 h-3 rounded-full bg-orange-500"></div>
                      </div>
                      <div className="space-y-2 pb-2">
                        <span className="inline-block text-sm font-black text-orange-600 tracking-widest uppercase bg-orange-50 px-3 py-1 rounded-full">
                          {item.year}
                        </span>
                        <p className="text-slate-700 font-semibold text-xl leading-relaxed">{item.event}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sticky Sidebar (Right Side - 25%) */}
            <aside className="lg:col-span-1 space-y-8">
              <div className="lg:sticky lg:top-28 space-y-8">
                {/* Profile Card */}
                <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden">
                  <div className="p-8 pb-4 flex flex-col items-center">
                    <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-orange-100 shrink-0 shadow-lg bg-slate-50 mb-6">
                      <img 
                        src={FOUNDER_DATA.image} 
                        alt="Danny Shash" 
                        className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                      />
                    </div>
                    <h4 className="text-xl font-bold serif text-emerald-950 mb-1">Danny Shash</h4>
                    <p className="text-sm text-orange-600 font-bold tracking-widest uppercase mb-6">Mama Danny</p>
                    
                    <ul className="w-full space-y-4 text-slate-600 border-t border-slate-50 pt-6">
                      <li className="flex items-center gap-3 text-sm font-medium">
                        <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center shrink-0">
                          <MapPin className="text-emerald-600" size={14} />
                        </div>
                        <span>Gashora, Rwanda</span>
                      </li>
                      <li className="flex items-center gap-3 text-sm font-medium">
                        <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center shrink-0">
                          <Heart className="text-emerald-600" size={14} />
                        </div>
                        <span>Full-time Care</span>
                      </li>
                      <li className="flex items-center gap-3 text-sm font-medium">
                        <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center shrink-0">
                          <Youtube className="text-emerald-600" size={14} />
                        </div>
                        <span>Content Creator</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div className="bg-slate-50 p-6 flex justify-center gap-6">
                    <a href="https://www.youtube.com/@danni_shash" target="_blank" className="text-slate-400 hover:text-emerald-600 transition-colors"><Youtube size={18} /></a>
                    <a href="https://www.instagram.com/danni_shash/" target="_blank" className="text-slate-400 hover:text-emerald-600 transition-colors"><Instagram size={18} /></a>
                    <a href="https://www.facebook.com/danni.shash/" target="_blank" className="text-slate-400 hover:text-emerald-600 transition-colors"><Facebook size={18} /></a>
                  </div>
                </div>

                {/* Engagement Card */}
                <div className="bg-orange-600 p-8 rounded-[2.5rem] text-white shadow-lg relative overflow-hidden group">
                  <Quote className="absolute -top-6 -right-6 text-orange-500/30 group-hover:scale-110 transition-transform" size={120} />
                  <div className="relative z-10">
                    <p className="text-lg italic font-medium leading-relaxed mb-6">
                      "Every victory, no matter how small, is a step toward a future these children once thought impossible."
                    </p>
                    <Link to="/donate" className="flex items-center justify-between bg-white/10 hover:bg-white/20 border border-white/20 p-4 rounded-2xl transition-all group/btn">
                      <span className="font-bold text-sm">Support Danny's Mission</span>
                      <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                    </Link>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FounderStory;
