
import React, { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import { X, Maximize2, ChevronRight, Play } from 'lucide-react';

interface Photo {
  id: string;
  url: string;
}

const Gallery: React.FC = () => {
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);

  const photos: Photo[] = [
    { id: '1', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children1.jpg' },
    { id: '2', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children12.jpg' },
    { id: '3', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children2.jpg' },
    { id: '4', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children3.jpg' },
    { id: '5', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children4.jpg' },
    { id: '6', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children5.jpg' },
    { id: '7', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children6.jpg' },
    { id: '8', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children7.jpg' },
    { id: '9', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children8.jpg' },
    { id: '10', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/fosterimage.jpg' },
    { id: '11', url: 'https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/nutritionpic.jpg' },
  ];

  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7] min-h-screen">
      {/* Lightbox Modal */}
      {selectedPhoto && (
        <div 
          className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-md flex items-center justify-center p-4 md:p-12 animate-in fade-in duration-300"
          onClick={() => setSelectedPhoto(null)}
        >
          <button className="absolute top-8 right-8 text-white/70 hover:text-white transition-colors z-[110]">
            <X size={40} />
          </button>
          <div 
            className="max-w-5xl w-full h-full flex flex-col items-center justify-center gap-6"
            onClick={e => e.stopPropagation()}
          >
            <div className="relative w-full max-h-[90vh] flex items-center justify-center">
              <img 
                src={selectedPhoto.url} 
                alt="Gashora Moment" 
                className="max-w-full max-h-full object-contain rounded-2xl shadow-2xl border-4 border-white/10"
              />
            </div>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 md:px-6">
        <SectionHeader 
          title="Moments of Hope" 
          subtitle="A visual journey through Gashora Hope House. Every smile is a story of resilience and the power of love."
        />

        {/* Masonry-Style Responsive Grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-8 space-y-8 mt-16">
          {photos.map((photo) => (
            <div 
              key={photo.id} 
              className="relative break-inside-avoid group cursor-pointer overflow-hidden rounded-[2rem] shadow-xl border-4 border-white bg-slate-200"
              onClick={() => setSelectedPhoto(photo)}
            >
              <img 
                src={photo.url} 
                alt="Gashora life" 
                className="w-full h-auto object-cover transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
              />
              
              <div className="absolute inset-0 bg-emerald-950/20 opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
                <div className="bg-white/90 backdrop-blur-sm p-4 rounded-full text-emerald-900 shadow-xl transform scale-75 group-hover:scale-100 transition-transform duration-500">
                  <Maximize2 size={24} />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Video Stories Callout */}
        <div className="mt-32 bg-emerald-950 rounded-[3rem] p-12 md:p-20 relative overflow-hidden shadow-2xl border-b-8 border-orange-600">
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-900 rounded-full blur-[100px] opacity-40 -translate-y-1/2 translate-x-1/2"></div>
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8 text-center lg:text-left">
              <span className="inline-flex items-center gap-2 bg-orange-600/20 text-orange-400 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest">
                <Play size={14} fill="currentColor" /> Live from the Village
              </span>
              <h2 className="text-4xl md:text-5xl font-bold serif text-white leading-tight">
                Watch Our Stories <br /> Come to Life
              </h2>
              <p className="text-emerald-100/70 text-lg leading-relaxed max-w-lg mx-auto lg:mx-0">
                Danny documents the daily miracles in Gashora on our YouTube channel. Follow the journey from rural Rwanda to the hearts of children.
              </p>
              <a 
                href="https://www.youtube.com/@danni_shash" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 bg-white text-emerald-950 px-8 py-4 rounded-xl font-bold hover:bg-orange-50 transition-all group shadow-xl"
              >
                Go to YouTube Channel <ChevronRight className="group-hover:translate-x-1 transition-transform" />
              </a>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <a href="https://www.youtube.com/watch?v=J-BvnGLqAeA" target="_blank" rel="noopener noreferrer" className="aspect-video bg-emerald-900 rounded-2xl overflow-hidden shadow-2xl border-2 border-emerald-800 relative group cursor-pointer">
                <img src="https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children12.jpg" className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" alt="Video thumbnail" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-white text-emerald-950 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform"><Play size={20} fill="currentColor" className="ml-0.5" /></div>
                </div>
              </a>
              <a href="https://www.youtube.com/watch?v=8KDEhUjlrfE" target="_blank" rel="noopener noreferrer" className="aspect-video bg-emerald-900 rounded-2xl overflow-hidden shadow-2xl border-2 border-emerald-800 relative group cursor-pointer">
                <img src="https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/children8.jpg" className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity" alt="Video thumbnail" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-12 h-12 bg-white text-emerald-950 rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform"><Play size={20} fill="currentColor" className="ml-0.5" /></div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Gallery;
