
import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Users, GraduationCap, Utensils, ArrowRight, Play, Quote } from 'lucide-react';
import SectionHeader from '../components/SectionHeader';
import { STATS, PROGRAMS, FOUNDER_DATA } from '../data';

const Home: React.FC = () => {
  const iconMap: Record<string, React.ReactNode> = {
    'Children in Care': <Users />,
    'Meals Provided Yearly': <Utensils />,
    'Students Sponsored': <GraduationCap />,
    'Years in Gashora': <Heart />,
  };

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-screen min-h-[600px] flex items-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://raw.githubusercontent.com/armel12/hope-home-rwanda/383cb3696555edffea9c92c58e106c2399c2a997/images/Danishash.jpg" 
            className="w-full h-full object-cover brightness-[0.45]" 
            alt="Smiling children in Rwanda"
          />
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-white">
          <div className="max-w-3xl animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <span className="inline-block bg-orange-600 text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest mb-6 shadow-lg">
              Empowering the Future
            </span>
            <h1 className="text-5xl md:text-7xl font-bold serif leading-tight mb-8">
              Protecting the <span className="text-orange-400">Heart</span> of Gashora Village
            </h1>
            <p className="text-xl md:text-2xl text-emerald-50/90 mb-10 leading-relaxed font-light">
              We provide a safe haven, quality education, and unconditional love for vulnerable children in rural Bugesera.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link 
                to="/donate" 
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-10 py-4 rounded-xl font-bold text-lg text-center transition-all shadow-xl hover:-translate-y-1"
              >
                Donate Now
              </Link>
              <Link 
                to="/sponsor-a-child" 
                className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-10 py-4 rounded-xl font-bold text-lg text-center transition-all"
              >
                Sponsor a Child
              </Link>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center animate-bounce text-white/60">
          <div className="w-px h-12 bg-white/40 mb-2"></div>
          <span className="text-[10px] uppercase tracking-widest">Scroll Down</span>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-12 bg-emerald-950">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {STATS.map((stat, i) => (
              <div key={i} className="text-center group">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-emerald-900 text-orange-400 mb-4 group-hover:scale-110 transition-transform">
                  {React.cloneElement(iconMap[stat.label] as React.ReactElement<any>, { size: 28 })}
                </div>
                <div className="text-4xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-emerald-300/80 text-sm uppercase tracking-wider font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Founder Preview */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="absolute -right-24 top-24 w-96 h-96 bg-emerald-50 rounded-full blur-3xl opacity-60"></div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="aspect-[4/5] rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white bg-slate-100">
                <img 
                  src={FOUNDER_DATA.image} 
                  alt={`${FOUNDER_DATA.name} with children`}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-8 -right-8 bg-orange-600 text-white p-8 rounded-3xl shadow-xl max-w-[280px] hidden md:block border-4 border-white">
                <Quote className="text-orange-300 mb-4" size={32} />
                <p className="font-medium italic text-lg leading-relaxed">
                  {FOUNDER_DATA.bioShort}
                </p>
                <p className="mt-4 text-sm font-bold uppercase tracking-widest text-orange-200">
                  Mama Danny
                </p>
              </div>
            </div>
            
            <div className="space-y-8">
              <div>
                <span className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-2 block">Our Purpose</span>
                <SectionHeader 
                  title="From New York Streets to Rwanda's Rolling Hills" 
                  subtitle="Five years ago, Danny Shash left behind a comfortable life in New York to follow a calling. What started as a humanitarian mission became Gashora Hope House, a sanctuary for those who need it most."
                  centered={false}
                />
              </div>
              
              <div className="space-y-6 text-slate-600 leading-relaxed text-lg">
                <p>
                  In the heart of Bugesera District, we believe that every child deserves a home, an education, and the opportunity to dream. 
                </p>
                <p>
                  Our center isn't just a facility; it's a family. We provide full-time foster care, nutritional support, and high-quality education to children from disadvantaged backgrounds in Gashora Village.
                </p>
              </div>
              
              <div className="pt-4 flex items-center gap-6">
                <Link 
                  to="/founder" 
                  className="inline-flex items-center gap-2 text-emerald-700 font-bold hover:gap-4 transition-all"
                >
                  Read Danny's Full Story <ArrowRight size={20} />
                </Link>
                <Link 
                  to="/about" 
                  className="px-6 py-2 border-2 border-slate-200 rounded-xl text-slate-600 font-bold hover:bg-slate-50 transition-all"
                >
                  About Our Center
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Programs Preview */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <SectionHeader 
              title="Our Pillars of Care" 
              subtitle="We take a holistic approach to child development, focusing on every aspect of a child's well-being."
              centered={false}
            />
            <Link to="/programs" className="bg-emerald-50 text-emerald-700 px-6 py-3 rounded-xl font-bold hover:bg-emerald-100 transition-all mb-4">
              View All Programs
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {PROGRAMS.slice(0, 3).map((p, i) => (
              <div key={i} className="group bg-slate-50 rounded-[2.5rem] overflow-hidden hover:shadow-xl transition-all border border-slate-100">
                <div className="h-64 overflow-hidden">
                  <img src={p.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt={p.title} />
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-bold serif mb-3 text-emerald-900">{p.title}</h3>
                  <p className="text-slate-600 mb-6 line-clamp-2">{p.desc}</p>
                  <Link to={`/programs/${p.id}`} className="text-orange-600 font-bold flex items-center gap-1 group-hover:gap-2 transition-all">
                    Learn More <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-emerald-700 relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-emerald-800 -skew-x-12 translate-x-1/4"></div>
        </div>
        <div className="container mx-auto px-4 md:px-6 relative z-10 text-center">
          <h2 className="text-4xl md:text-5xl font-bold serif text-white mb-6">Will You Be Part of Our Story?</h2>
          <p className="text-xl text-emerald-50 max-w-2xl mx-auto mb-10 leading-relaxed">
            Your generosity can provide a bed, a meal, and a future for a child in Gashora. No gift is too small.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              to="/donate" 
              className="bg-orange-600 hover:bg-orange-700 text-white px-10 py-4 rounded-xl font-bold text-lg transition-all shadow-xl hover:-translate-y-1"
            >
              Make a Donation
            </Link>
            <Link 
              to="/volunteer-application" 
              className="bg-white text-emerald-900 hover:bg-emerald-50 px-10 py-4 rounded-xl font-bold text-lg transition-all shadow-xl hover:-translate-y-1"
            >
              Volunteer With Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
