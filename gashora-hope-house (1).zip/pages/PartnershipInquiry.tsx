
import React, { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import { Send, Building2, Globe, HeartHandshake, CheckCircle2 } from 'lucide-react';

const PartnershipInquiry: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (submitted) {
    return (
      <div className="pt-32 pb-24 flex items-center justify-center min-h-[70vh]">
        <div className="max-w-xl w-full mx-4 bg-white p-12 rounded-[3rem] shadow-2xl text-center animate-in zoom-in duration-500">
          <div className="w-20 h-20 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 size={48} />
          </div>
          <h2 className="text-4xl font-bold serif text-emerald-950 mb-4">Inquiry Sent!</h2>
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            We are honored by your interest in partnering with Gashora Hope House. Our development director will review your proposal and reach out to you within a few days.
          </p>
          <button 
            onClick={() => setSubmitted(false)}
            className="bg-orange-600 text-white px-10 py-4 rounded-xl font-bold hover:bg-orange-700 transition-all"
          >
            Back to Form
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <SectionHeader 
            title="Partnership Inquiry" 
            subtitle="Let's build something lasting together. We are always looking for organizations and individuals who want to help us scale our impact in Rwanda."
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mt-12 items-start">
            {/* Info Cards */}
            <div className="space-y-6">
              <div className="bg-emerald-900 text-white p-8 rounded-[2.5rem] shadow-lg">
                <Building2 className="text-orange-400 mb-4" size={32} />
                <h4 className="text-xl font-bold serif mb-2">Corporate Giving</h4>
                <p className="text-emerald-100/70 text-sm leading-relaxed">
                  Support us through CSR initiatives, employee matching, or infrastructure grants.
                </p>
              </div>
              <div className="bg-white p-8 rounded-[2.5rem] shadow-lg border border-slate-100">
                <Globe className="text-emerald-600 mb-4" size={32} />
                <h4 className="text-xl font-bold serif text-emerald-950 mb-2">NGO Collaboration</h4>
                <p className="text-slate-500 text-sm leading-relaxed">
                  Join forces on specific outreach programs in Bugesera District.
                </p>
              </div>
              <div className="bg-orange-600 text-white p-8 rounded-[2.5rem] shadow-lg">
                <HeartHandshake className="text-white mb-4" size={32} />
                <h4 className="text-xl font-bold serif mb-2">Church & Schools</h4>
                <p className="text-orange-100 text-sm leading-relaxed">
                  Engage your community in awareness campaigns and fundraising for Gashora.
                </p>
              </div>
            </div>

            {/* Inquiry Form */}
            <div className="lg:col-span-2 bg-white p-10 md:p-14 rounded-[3rem] shadow-2xl border border-slate-100">
              <h3 className="text-2xl font-bold serif text-emerald-950 mb-8">Proposal Details</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Organization Name</label>
                  <input required type="text" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all" placeholder="Your Charity / Company Name" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Contact Person</label>
                    <input required type="text" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all" placeholder="Full Name" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Email Address</label>
                    <input required type="email" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all" placeholder="name@org.com" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Type of Partnership</label>
                  <select required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all">
                    <option value="">Select Type...</option>
                    <option>Corporate Partnership</option>
                    <option>NGO / Strategic Alliance</option>
                    <option>Faith-Based Organization</option>
                    <option>Educational Institution</option>
                    <option>Individual Philanthropy</option>
                    <option>Other</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Partnership Proposal / Goals</label>
                  <textarea required rows={5} className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all resize-none" placeholder="Describe how you'd like to support our mission..."></textarea>
                </div>

                <button 
                  type="submit" 
                  className="w-full bg-emerald-950 hover:bg-black text-white py-5 rounded-2xl font-bold text-xl shadow-lg transition-all flex items-center justify-center gap-3"
                >
                  <Send size={20} /> Submit Inquiry
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PartnershipInquiry;
