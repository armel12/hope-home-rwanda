
import React from 'react';
import { Link } from 'react-router-dom';
import SectionHeader from '../components/SectionHeader';
import { Home as HomeIcon, GraduationCap, Apple, HeartPulse, BrainCircuit, Users2, ArrowRight } from 'lucide-react';
import { PROGRAMS } from '../data';

const Programs: React.FC = () => {
  const iconMap: Record<string, React.ReactNode> = {
    'Foster Care & Shelter': <HomeIcon />,
    'Education Support': <GraduationCap />,
    'Nutrition & Healthy Meals': <Apple />,
    'Healthcare Access': <HeartPulse />,
    'Psychological Support': <BrainCircuit />,
    'Community Reintegration': <Users2 />
  };

  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeader 
          title="Empowerment Through Holistic Care" 
          subtitle="We don't just provide a roof; we provide a future. Explore the programs that make our impact sustainable."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mt-16">
          {PROGRAMS.map((p, i) => (
            <div key={i} className="bg-white rounded-[2rem] overflow-hidden shadow-xl border border-slate-100 flex flex-col group">
              <div className="h-60 overflow-hidden relative bg-slate-100">
                <img src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md p-3 rounded-2xl text-emerald-700 shadow-lg">
                  {React.cloneElement(iconMap[p.title] as React.ReactElement<any>, { size: 24 })}
                </div>
              </div>
              <div className="p-8 flex-grow">
                <h3 className="text-2xl font-bold serif text-emerald-950 mb-4">{p.title}</h3>
                <p className="text-slate-600 leading-relaxed mb-6">
                  {p.desc}
                </p>
                <Link to={`/programs/${p.id}`} className="text-emerald-700 font-bold inline-flex items-center gap-2 group-hover:gap-4 transition-all">
                  See Objectives <ArrowRight size={18} />
                </Link>
              </div>
              <div className="px-8 pb-8">
                <Link 
                  to={`/programs/${p.id}`}
                  className="w-full py-4 bg-emerald-50 text-emerald-700 rounded-xl font-bold hover:bg-emerald-600 hover:text-white text-center block transition-all shadow-sm"
                >
                  Support This Program
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Programs;
