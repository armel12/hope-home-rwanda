
import React from 'react';
import SectionHeader from '../components/SectionHeader';
import { Mail, Phone, MapPin, Youtube, Facebook, Instagram, Send } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7]">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeader 
          title="We'd Love to Hear From You" 
          subtitle="Questions about volunteering, donating, or visiting? Get in touch and our team will get back to you shortly."
        />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mt-12 items-start">
          {/* Contact Info */}
          <div className="space-y-12">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="p-8 bg-white rounded-3xl shadow-lg border border-slate-100">
                <MapPin className="text-orange-600 mb-4" size={32} />
                <h4 className="text-xl font-bold serif text-emerald-950 mb-2">Our Location</h4>
                <p className="text-slate-600 text-sm leading-relaxed">
                  Gashora Village,<br />Bugesera District,<br />Rwanda
                </p>
              </div>
              <div className="p-8 bg-white rounded-3xl shadow-lg border border-slate-100">
                <Mail className="text-orange-600 mb-4" size={32} />
                <h4 className="text-xl font-bold serif text-emerald-950 mb-2">Email Us</h4>
                <p className="text-slate-600 text-sm leading-relaxed">
                  hello@gashorahope.org<br />danny@gashorahope.org
                </p>
              </div>
            </div>

            <div className="bg-emerald-900 p-10 rounded-[2.5rem] text-white">
              <h4 className="text-2xl font-bold serif mb-6">Stay Connected</h4>
              <p className="text-emerald-50/70 mb-8">Follow Danny's journey and see the children's progress in real-time on our social platforms.</p>
              <div className="flex flex-wrap gap-6">
                <a href="https://www.youtube.com/@danni_shash" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:text-orange-400 transition-colors">
                  <Youtube /> <span className="font-bold">YouTube</span>
                </a>
                <a href="https://www.instagram.com/danni_shash/?hl=en" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:text-orange-400 transition-colors">
                  <Instagram /> <span className="font-bold">Instagram</span>
                </a>
                <a href="https://www.facebook.com/danni.shash/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 hover:text-orange-400 transition-colors">
                  <Facebook /> <span className="font-bold">Facebook</span>
                </a>
              </div>
            </div>

            <div className="relative aspect-square w-full rounded-[2.5rem] overflow-hidden shadow-2xl bg-slate-200 group border-4 border-white">
              {/* Actual Google Maps Embed */}
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15945.727525381836!2d30.2223835!3d-2.2285514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x19d901618683e97d%3A0x6b872c676d90610c!2sGashora!5e0!3m2!1sen!2srw!4v1715694382042!5m2!1sen!2srw" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                className="grayscale-[20%] group-hover:grayscale-0 transition-all duration-700"
              ></iframe>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white p-10 md:p-14 rounded-[3rem] shadow-2xl border border-slate-100">
            <h3 className="text-3xl font-bold serif text-emerald-950 mb-8">Send a Message</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Full Name</label>
                  <input 
                    type="text" 
                    placeholder="John Doe" 
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700 ml-1">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="john@example.com" 
                    className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 ml-1">Subject</label>
                <select className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all">
                  <option>General Inquiry</option>
                  <option>Donations & Sponsorship</option>
                  <option>Volunteering</option>
                  <option>Press & Media</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 ml-1">Your Message</label>
                <textarea 
                  rows={6} 
                  placeholder="Tell us how you'd like to get involved..." 
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-6 outline-none focus:border-emerald-500 transition-all resize-none"
                ></textarea>
              </div>
              <button 
                type="submit" 
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-5 rounded-2xl font-bold text-xl shadow-lg transition-all flex items-center justify-center gap-3"
              >
                <Send size={20} /> Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
