
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import SectionHeader from '../components/SectionHeader';
import { 
  Home as HomeIcon, GraduationCap, Apple, HeartPulse, BrainCircuit, Users2, 
  CheckCircle2, ArrowLeft, Heart, Target, Loader2, X, User, Mail, ChevronRight, ChevronLeft, EyeOff
} from 'lucide-react';
import { PROGRAMS } from '../data';

const PayPalIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5">
    <path fill="#003087" d="M7.076 21.337H9l.87-5.428h2.027c3.125 0 5.535-1.42 6.035-5.016.236-1.74-.02-3.076-1.02-4.1C15.895 5.74 14.1 5.337H5.667a.49.49 0 0 0-.484.41L2.628 21.838a.333.333 0 0 0 .328.386H5.43l.533-3.328h.58l.533 3.328z" />
    <path fill="#009cde" d="M11.6 5.337c-2.5 0-4.295.403-5.3 1.41-.996 1.027-1.256 2.364-1.02 4.104.5 3.596 2.91 5.016 6.035 5.016h2.027l.87-5.428" />
  </svg>
);

const StripeIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5">
    <path fill="#635BFF" d="M13.962 8.185c0-1.026-.816-1.44-2.016-1.44-1.392 0-2.88.456-2.88.456l-.408-2.352s1.512-.648 3.528-.648c2.976 0 4.752 1.416 4.752 4.056 0 3.312-4.512 3.696-4.512 5.064 0 .576.48.888 1.272.888 1.488 0 3.192-.624 3.192-.624l.432 2.376s-1.608.744-3.816.744c-3.144 0-4.872-1.464-4.872-3.96 0-3.336 4.872-3.816 4.872-5.184z" />
  </svg>
);

const MasterCardIcon = () => (
  <div className="flex -space-x-1.5">
    <div className="w-4 h-4 rounded-full bg-[#EB001B]"></div>
    <div className="w-4 h-4 rounded-full bg-[#F79E1B] mix-blend-multiply opacity-90"></div>
  </div>
);

const MoMoIcon = () => (
  <div className="w-7 h-5 bg-[#FFCC00] rounded flex items-center justify-center p-0.5">
    <div className="text-[5px] font-black text-[#004F9E] flex flex-col items-center leading-none">
      <span>MTN</span>
      <span>momo</span>
    </div>
  </div>
);

const ProgramDetail: React.FC = () => {
  const { programId } = useParams<{ programId: string }>();
  const [selectedOption, setSelectedOption] = useState<{label: string, price: number, id: string} | null>(null);
  const [step, setStep] = useState(1);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [donorInfo, setDonorInfo] = useState({ name: '', email: '', country: '' });
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);
  const [isRedirecting, setIsRedirecting] = useState(false);

  const program = PROGRAMS.find(p => p.id === programId);

  const iconMap: Record<string, React.ReactNode> = {
    'Foster Care & Shelter': <HomeIcon />,
    'Education Support': <GraduationCap />,
    'Nutrition & Healthy Meals': <Apple />,
    'Healthcare Access': <HeartPulse />,
    'Psychological Support': <BrainCircuit />,
    'Community Reintegration': <Users2 />
  };

  const paymentMethods = [
    { id: 'paypal', name: 'PayPal', icon: <PayPalIcon />, url: 'https://www.paypal.com/donate' },
    { id: 'stripe', name: 'Stripe', icon: <StripeIcon />, url: 'https://checkout.stripe.com/pay' },
    { id: 'mastercard', name: 'MasterCard', icon: <MasterCardIcon />, url: 'https://www.mastercard.com/gateway' },
    { id: 'momo', name: 'MoMo Pay', icon: <MoMoIcon />, url: 'https://momo.mtn.co.rw/pay' },
  ];

  const handleSupportPayment = () => {
    if (!selectedOption || !paymentMethod) return;
    setIsRedirecting(true);
    const method = paymentMethods.find(m => m.id === paymentMethod);
    const donorName = isAnonymous ? 'Anonymous' : (donorInfo.name || 'Friend');
    const redirectUrl = `${method?.url}?amount=${selectedOption.price}&item=${encodeURIComponent(selectedOption.label)}&donor=${encodeURIComponent(donorName)}`;
    setTimeout(() => {
      window.location.href = redirectUrl;
    }, 2500);
  };

  const resetModal = () => {
    setSelectedOption(null);
    setStep(1);
    setPaymentMethod(null);
    setIsAnonymous(false);
  };

  if (!program) return <div className="pt-40 text-center">Program Not Found</div>;

  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7] min-h-screen relative">
      {selectedOption && !isRedirecting && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden relative border border-emerald-50">
            <button onClick={resetModal} className="absolute top-6 right-6 text-slate-400 hover:text-slate-600 transition-colors z-20"><X size={24} /></button>
            <div className="p-10">
              <div className="text-center mb-8">
                {/* Fixed: Use React.ReactElement<any> to allow size prop in cloneElement */}
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">{React.cloneElement(iconMap[program.title] as React.ReactElement<any>, { size: 32 })}</div>
                <h3 className="text-2xl font-bold serif text-emerald-950">{selectedOption.label}</h3>
                <p className="text-emerald-700 font-bold">${selectedOption.price} Contribution</p>
                <div className="flex items-center justify-center gap-2 mt-4"><div className={`w-2 h-2 rounded-full ${step === 1 ? 'bg-orange-600' : 'bg-slate-200'}`}></div><div className={`w-2 h-2 rounded-full ${step === 2 ? 'bg-orange-600' : 'bg-slate-200'}`}></div></div>
              </div>

              {step === 1 ? (
                <div className="animate-in slide-in-from-right duration-300">
                  <div className="flex justify-between items-center mb-6">
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Your Details (Optional)</p>
                    <button onClick={() => setIsAnonymous(!isAnonymous)} className={`text-xs font-bold flex items-center gap-1.5 transition-colors ${isAnonymous ? 'text-emerald-600' : 'text-slate-400 hover:text-emerald-600'}`}><EyeOff size={14} /> {isAnonymous ? 'Anonymous On' : 'Go Anonymous'}</button>
                  </div>
                  <div className={`space-y-4 mb-8 transition-opacity ${isAnonymous ? 'opacity-30 grayscale pointer-events-none' : 'opacity-100'}`}>
                    <div className="relative"><User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} /><input type="text" placeholder="Name" className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all" value={donorInfo.name} onChange={(e) => setDonorInfo({...donorInfo, name: e.target.value})} disabled={isAnonymous} /></div>
                    <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} /><input type="email" placeholder="Email" className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all" value={donorInfo.email} onChange={(e) => setDonorInfo({...donorInfo, email: e.target.value})} disabled={isAnonymous} /></div>
                  </div>
                  <button onClick={() => setStep(2)} className="w-full bg-emerald-700 hover:bg-emerald-800 text-white py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-2">Payment Method <ChevronRight size={18} /></button>
                </div>
              ) : (
                <div className="animate-in slide-in-from-right duration-300">
                  <div className="space-y-3 mb-8">
                    {paymentMethods.map((method) => (
                      <button key={method.id} onClick={() => setPaymentMethod(method.id)} className={`flex items-center p-4 rounded-xl border-2 transition-all gap-4 w-full text-left ${paymentMethod === method.id ? 'border-emerald-600 bg-emerald-50 text-emerald-800 shadow-sm' : 'border-slate-100 bg-slate-50 text-slate-600 hover:bg-white'}`}>
                        <div className="bg-white p-1 rounded-md shrink-0 flex items-center justify-center w-10 h-8 shadow-sm">
                           {method.icon}
                        </div>
                        <span className="font-bold text-sm tracking-wide">{method.name}</span>
                        {paymentMethod === method.id && <CheckCircle2 className="ml-auto text-emerald-600" size={18} />}
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => setStep(1)} className="flex-1 bg-slate-100 text-slate-600 py-4 rounded-xl font-bold"><ChevronLeft size={18} /> Back</button>
                    <button onClick={handleSupportPayment} disabled={!paymentMethod} className="flex-[2] bg-orange-600 hover:bg-orange-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg disabled:opacity-50">Confirm Support</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {isRedirecting && (
        <div className="fixed inset-0 z-[110] bg-white/95 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-500 text-center px-6">
          <div className="space-y-6 max-w-sm">
            <Loader2 className="w-16 h-16 text-emerald-600 animate-spin mx-auto" />
            <h2 className="text-2xl font-bold serif text-emerald-950">Confirming with Gateway</h2>
            <p className="text-slate-500">Connecting to our secure checkout partner. Your support for {program.title} means the world to us.</p>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 md:px-6">
        <Link to="/programs" className="inline-flex items-center gap-2 text-emerald-700 font-bold mb-8 hover:-translate-x-1 transition-transform"><ArrowLeft size={20} /> Back to All Programs</Link>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div className="space-y-12">
            <div>
              {/* Fixed: Use React.ReactElement<any> to allow size prop in cloneElement */}
              <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mb-6 shadow-md">{React.cloneElement(iconMap[program.title] as React.ReactElement<any>, { size: 32 })}</div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold serif text-emerald-950 mb-6 leading-tight">{program.title}</h1>
              <p className="text-xl text-slate-600 leading-relaxed font-light italic">"{program.longDesc}"</p>
            </div>
            <div className="space-y-6">
              <h3 className="text-2xl font-bold serif text-emerald-900 flex items-center gap-3"><Target className="text-orange-600" /> Core Objectives</h3>
              <div className="grid grid-cols-1 gap-4">
                {program.objectives.map((obj: string, i: number) => (
                  <div key={i} className="flex gap-4 p-5 bg-white rounded-2xl shadow-sm border border-slate-100"><CheckCircle2 className="text-emerald-500 shrink-0" size={24} /><span className="text-slate-700 font-medium">{obj}</span></div>
                ))}
              </div>
            </div>
          </div>
          <div className="space-y-12 lg:sticky lg:top-32">
            <div className="aspect-[4/3] rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white"><img src={program.img} alt={program.title} className="w-full h-full object-cover" /></div>
            <div className="bg-white p-10 rounded-[3rem] shadow-2xl border border-slate-100">
              <h3 className="text-2xl font-bold serif text-emerald-950 mb-8 flex items-center gap-2"><Heart className="text-orange-600" fill="currentColor" /> Directly Support {program.title}</h3>
              <div className="space-y-4 mb-10">
                {program.supportOptions.map((opt: any) => (
                  <button key={opt.id} onClick={() => setSelectedOption({label: opt.label, price: opt.numericPrice, id: opt.id})} className="w-full flex justify-between items-center p-5 rounded-2xl border-2 border-slate-50 hover:border-emerald-500 hover:bg-emerald-50 transition-all text-left group disabled:opacity-70"><span className="font-bold text-slate-700 group-hover:text-emerald-800">{opt.label}</span><span className="text-emerald-600 font-black">{opt.price}</span></button>
                ))}
              </div>
              <Link to="/donate" className="w-full bg-orange-600 hover:bg-orange-700 text-white py-5 rounded-2xl font-bold text-xl text-center block shadow-lg transition-all transform hover:scale-[1.02]">Make a General Donation</Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgramDetail;
