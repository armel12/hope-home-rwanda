
import React, { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import { Heart, CreditCard, ShieldCheck, CheckCircle2, DollarSign, Loader2, Globe, User, Mail, MapPin, Lock, EyeOff } from 'lucide-react';
import { COUNTRIES } from '../data';

const PayPalIcon = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6">
    <path fill="#003087" d="M7.076 21.337H9l.87-5.428h2.027c3.125 0 5.535-1.42 6.035-5.016.236-1.74-.02-3.076-1.02-4.1C15.895 5.74 14.1 5.337H5.667a.49.49 0 0 0-.484.41L2.628 21.838a.333.333 0 0 0 .328.386H5.43l.533-3.328h.58l.533 3.328z" />
    <path fill="#009cde" d="M11.6 5.337c-2.5 0-4.295.403-5.3 1.41-.996 1.027-1.256 2.364-1.02 4.104.5 3.596 2.91 5.016 6.035 5.016h2.027l.87-5.428" />
  </svg>
);

const StripeIcon = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6">
    <path fill="#635BFF" d="M13.962 8.185c0-1.026-.816-1.44-2.016-1.44-1.392 0-2.88.456-2.88.456l-.408-2.352s1.512-.648 3.528-.648c2.976 0 4.752 1.416 4.752 4.056 0 3.312-4.512 3.696-4.512 5.064 0 .576.48.888 1.272.888 1.488 0 3.192-.624 3.192-.624l.432 2.376s-1.608.744-3.816.744c-3.144 0-4.872-1.464-4.872-3.96 0-3.336 4.872-3.816 4.872-5.184z" />
  </svg>
);

const MasterCardIcon = () => (
  <div className="flex -space-x-2">
    <div className="w-5 h-5 rounded-full bg-[#EB001B]"></div>
    <div className="w-5 h-5 rounded-full bg-[#F79E1B] mix-blend-multiply opacity-90"></div>
  </div>
);

const MoMoIcon = () => (
  <div className="w-8 h-6 bg-[#FFCC00] rounded flex items-center justify-center p-0.5 shadow-sm">
    <div className="text-[7px] font-black text-[#004F9E] flex flex-col items-center leading-none">
      <span>MTN</span>
      <span className="text-[6px] tracking-tighter">momo</span>
    </div>
  </div>
);

const Donate: React.FC = () => {
  const [amount, setAmount] = useState<number | null>(50);
  const [frequency, setFrequency] = useState<'once' | 'monthly'>('monthly');
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [donorInfo, setDonorInfo] = useState({ name: '', email: '', country: '' });
  const [isRedirecting, setIsRedirecting] = useState(false);

  const tiers = [
    { val: 25, desc: 'Provides meals for 1 child for a month.' },
    { val: 50, desc: 'Covers school fees & supplies for 1 student.' },
    { val: 100, desc: 'Provides full healthcare & nutrition for 2 children.' },
    { val: 250, desc: 'Contributes to shelter maintenance & caregiver salaries.' },
  ];

  const paymentMethods = [
    { id: 'paypal', name: 'PayPal', icon: <PayPalIcon />, url: 'https://www.paypal.com/donate', color: 'text-blue-600' },
    { id: 'stripe', name: 'Stripe', icon: <StripeIcon />, url: 'https://checkout.stripe.com/pay', color: 'text-indigo-600' },
    { id: 'mastercard', name: 'MasterCard', icon: <MasterCardIcon />, url: 'https://www.mastercard.com/gateway', color: 'text-orange-600' },
    { id: 'momo', name: 'MoMo Pay', icon: <MoMoIcon />, url: 'https://momo.mtn.co.rw/pay', color: 'text-yellow-500' },
  ];

  const canProceed = amount && amount > 0 && paymentMethod;

  const handleProceedToPayment = () => {
    if (!canProceed) return;
    setIsRedirecting(true);
    const selectedMethod = paymentMethods.find(m => m.id === paymentMethod);
    const nameParam = isAnonymous ? 'Anonymous' : (donorInfo.name || 'Friend');
    const checkoutUrl = `${selectedMethod?.url}?amount=${amount}&currency=USD&item=Donation_Gashora&donor=${encodeURIComponent(nameParam)}`;
    setTimeout(() => {
      window.location.href = checkoutUrl;
    }, 2500);
  };

  const selectedMethodObj = paymentMethods.find(m => m.id === paymentMethod);

  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7] relative min-h-screen">
      {isRedirecting && (
        <div className="fixed inset-0 z-[100] bg-white/95 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-500">
          <div className="text-center space-y-6 max-w-sm px-6">
            <div className="relative inline-block">
              <Loader2 className="w-16 h-16 text-emerald-600 animate-spin mx-auto" />
              <div className="absolute inset-0 m-auto flex items-center justify-center">
                <div className="bg-white p-2 rounded-lg shadow-md">
                   {selectedMethodObj?.icon}
                </div>
              </div>
            </div>
            <h2 className="text-2xl font-bold serif text-emerald-950">Redirecting to Secure Checkout</h2>
            <p className="text-slate-500">You are being transferred to <strong>{selectedMethodObj?.name}</strong> to complete your gift securely.</p>
            <div className="flex items-center justify-center gap-2 text-xs text-slate-400 font-bold uppercase tracking-widest">
              <ShieldCheck size={14} /> 256-Bit Encryption
            </div>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-6xl mx-auto">
          <SectionHeader 
            title="Make a Secure Gift" 
            subtitle="Choose an amount and your preferred payment method. Donor information is optional if you wish to remain anonymous."
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mt-12">
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white p-8 md:p-10 rounded-[2.5rem] shadow-xl border border-slate-100">
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-10 h-10 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold text-lg">1</div>
                  <h3 className="text-2xl font-bold serif text-emerald-950">Select Amount</h3>
                </div>

                <div className="flex gap-2 p-1 bg-slate-100 rounded-xl mb-8">
                  <button onClick={() => setFrequency('monthly')} className={`flex-1 py-3 rounded-lg font-bold text-sm transition-all ${frequency === 'monthly' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Give Monthly</button>
                  <button onClick={() => setFrequency('once')} className={`flex-1 py-3 rounded-lg font-bold text-sm transition-all ${frequency === 'once' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>One-time</button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                  {tiers.map((tier) => (
                    <button key={tier.val} onClick={() => setAmount(tier.val)} className={`py-6 rounded-2xl border-2 font-bold text-xl transition-all ${amount === tier.val ? 'border-orange-600 bg-orange-50 text-orange-700' : 'border-slate-100 hover:border-emerald-200'}`}>
                      ${tier.val}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400"><DollarSign size={20} /></div>
                  <input type="number" placeholder="Custom Amount" className="w-full bg-slate-50 border-2 border-slate-100 focus:border-emerald-500 rounded-xl py-4 pl-12 pr-4 font-bold text-lg outline-none transition-all" value={amount || ''} onChange={(e) => setAmount(Number(e.target.value))} />
                </div>
              </div>

              <div className="bg-white p-8 md:p-10 rounded-[2.5rem] shadow-xl border border-slate-100 transition-all">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center font-bold text-lg">2</div>
                    <h3 className="text-2xl font-bold serif text-emerald-950">Donor Details <span className="text-sm font-normal text-slate-400 italic font-sans">(Optional)</span></h3>
                  </div>
                  <button 
                    onClick={() => setIsAnonymous(!isAnonymous)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm transition-all ${isAnonymous ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                  >
                    <EyeOff size={16} /> {isAnonymous ? 'Donating Anonymously' : 'Donate Anonymously'}
                  </button>
                </div>

                <div className={`grid grid-cols-1 md:grid-cols-2 gap-6 transition-all duration-500 ${isAnonymous ? 'opacity-30 pointer-events-none grayscale' : 'opacity-100'}`}>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input type="text" placeholder="Your Name" className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all" value={donorInfo.name} onChange={(e) => setDonorInfo({...donorInfo, name: e.target.value})} disabled={isAnonymous} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Email Address</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input type="email" placeholder="email@example.com" className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all" value={donorInfo.email} onChange={(e) => setDonorInfo({...donorInfo, email: e.target.value})} disabled={isAnonymous} />
                    </div>
                  </div>
                  <div className="md:col-span-2 space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Country</label>
                    <div className="relative">
                      <select 
                        className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all appearance-none"
                        value={donorInfo.country} 
                        onChange={(e) => setDonorInfo({...donorInfo, country: e.target.value})} 
                        disabled={isAnonymous}
                      >
                        <option value="">Select Country...</option>
                        {COUNTRIES.map(c => (
                          <option key={c.name} value={c.name}>{c.flag} {c.name}</option>
                        ))}
                      </select>
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                        <Globe size={18} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-1 space-y-8 lg:sticky lg:top-32 h-fit">
              <div className="bg-emerald-900 text-white p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-800 rounded-full -translate-y-1/2 translate-x-1/2 opacity-30"></div>
                <div className="flex items-center gap-3 mb-8 relative z-10">
                  <div className="w-10 h-10 bg-emerald-800 text-orange-400 rounded-full flex items-center justify-center font-bold text-lg">3</div>
                  <h3 className="text-xl font-bold serif">Payment Method</h3>
                </div>

                <div className="space-y-3 mb-8 relative z-10">
                  {paymentMethods.map((method) => (
                    <button key={method.id} onClick={() => setPaymentMethod(method.id)} className={`flex items-center p-4 rounded-xl border-2 transition-all gap-4 w-full ${paymentMethod === method.id ? 'border-orange-500 bg-emerald-800 text-white shadow-lg' : 'border-emerald-800 bg-emerald-950/30 text-emerald-100 hover:bg-emerald-800'}`}>
                      <div className="bg-white p-1 rounded-md shrink-0 flex items-center justify-center w-12 h-10">
                         {method.icon}
                      </div>
                      <span className="font-bold text-sm uppercase tracking-wider">{method.name}</span>
                    </button>
                  ))}
                </div>

                <div className="p-5 bg-emerald-950/50 rounded-2xl border border-emerald-800 mb-8 relative z-10">
                  <div className="flex justify-between items-center text-sm font-bold border-b border-emerald-800 pb-3 mb-3">
                    <span className="text-emerald-300">Your Gift</span>
                    <span className="text-2xl font-serif text-white">${amount || 0}</span>
                  </div>
                  <p className="text-[11px] text-emerald-100/60 leading-relaxed italic text-center">
                    {selectedMethodObj ? `Secure checkout via ${selectedMethodObj.name}` : 'Select your payment provider above'}
                  </p>
                </div>

                <button onClick={handleProceedToPayment} disabled={!canProceed || isRedirecting} className="w-full bg-orange-600 hover:bg-orange-700 text-white py-5 rounded-2xl font-bold text-lg shadow-lg transition-all transform hover:scale-[1.02] disabled:opacity-40 disabled:hover:scale-100 relative z-10 flex items-center justify-center gap-3">
                  {isRedirecting ? <Loader2 className="animate-spin" /> : <CreditCard />} Confirm & Donate
                </button>
                
                <div className="mt-6 text-center relative z-10 opacity-60">
                   <div className="flex items-center justify-center gap-2 text-[10px] uppercase tracking-widest font-bold"><ShieldCheck size={14} /> Encrypted Gateway</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Donate;
