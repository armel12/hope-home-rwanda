
import React, { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import { Search, Filter, Heart, Loader2, X, User, Mail, ChevronRight, ChevronLeft, EyeOff, ShieldCheck, CheckCircle2, Globe } from 'lucide-react';
import { CHILDREN, COUNTRIES } from '../data';

const PayPalIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5">
    <path fill="#003087" d="M7.076 21.337H9l.87-5.428h2.027c3.125 0 5.535-1.42 6.035-5.016.236-1.74-.02-3.076-1.02-4.1C15.895 5.74 14.1 5.337H5.667a.49.49 0 0 0-.484.41L2.628 21.838a.333.333 0 0 0 .328.386H5.43l.533-3.328h.58l.533 3.328z" />
    <path fill="#009cde" d="M11.6 5.337c-2.5 0-4.295.403-5.3 1.41-.996 1.027-1.256 2.364-1.02 4.104.5 3.596 2.91 5.016 6.035 5.016h2.027l.87-5.428" />
  </svg>
);

const StripeIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5">
    <path fill="#635BFF" d="M13.962 8.185c0-1.026-.816-1.44-2.016-1.44-1.392 0-2.88.456-2.88.456l-.408-2.352s1.512-.648 3.528-.648c2.976 0 4.752 1.416 4.752 4.056 0 3.312-4.512 3.696-4.512 5.064 0 .576.48.888 1.272.888 1.488 0 3.192-.624 3.192-.624l.432 2.376s-1.608.744-3.816.744c-3.144 0-4.872-1.464-4.872-3.96 0-3.336 4.872-3.816 4.872-5.184z" />
  </svg>
);

const MasterCardIcon = () => (
  <div className="flex -space-x-1.5">
    <div className="w-4 h-4 rounded-full bg-[#EB001B]"></div>
    <div className="w-4 h-4 rounded-full bg-[#F79E1B] mix-blend-multiply opacity-90"></div>
  </div>
);

const MoMoIcon = () => (
  <div className="w-7 h-5 bg-[#FFCC00] rounded flex items-center justify-center p-0.5">
    <div className="text-[5px] font-black text-[#004F9E] flex flex-col items-center leading-none">
      <span>MTN</span>
      <span>momo</span>
    </div>
  </div>
);

const SponsorChild: React.FC = () => {
  const [selectedChild, setSelectedChild] = useState<{name: string, id: number | string} | null>(null);
  const [step, setStep] = useState(1);
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [donorInfo, setDonorInfo] = useState({ name: '', email: '', country: '' });
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);
  const [isRedirecting, setIsRedirecting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const paymentMethods = [
    { id: 'paypal', name: 'PayPal', icon: <PayPalIcon />, url: 'https://www.paypal.com/donate' },
    { id: 'stripe', name: 'Stripe', icon: <StripeIcon />, url: 'https://checkout.stripe.com/pay' },
    { id: 'mastercard', name: 'MasterCard', icon: <MasterCardIcon />, url: 'https://www.mastercard.com/gateway' },
    { id: 'momo', name: 'MoMo Pay', icon: <MoMoIcon />, url: 'https://momo.mtn.co.rw/pay' },
  ];

  const handleSponsorshipPayment = () => {
    if (!paymentMethod || !selectedChild) return;
    setIsRedirecting(true);
    const method = paymentMethods.find(m => m.id === paymentMethod);
    const donorName = isAnonymous ? 'Anonymous' : (donorInfo.name || 'Friend');
    const redirectUrl = `${method?.url}?amount=40&frequency=monthly&item=Sponsor_${selectedChild.name}&donor=${encodeURIComponent(donorName)}`;
    setTimeout(() => {
      window.location.href = redirectUrl;
    }, 2500);
  };

  const resetModal = () => {
    setSelectedChild(null);
    setStep(1);
    setPaymentMethod(null);
    setIsAnonymous(false);
  };

  const selectedMethodObj = paymentMethods.find(m => m.id === paymentMethod);

  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7] min-h-screen relative">
      {selectedChild && !isRedirecting && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden relative border border-emerald-50">
            <button onClick={resetModal} className="absolute top-6 right-6 text-slate-400 hover:text-slate-600 transition-colors z-20"><X size={24} /></button>
            <div className="p-10">
              <div className="text-center mb-8">
                <div className="relative inline-block mb-4">
                  <div className="w-16 h-16 rounded-full overflow-hidden border-4 border-orange-100 mx-auto bg-slate-100">
                    <img src={CHILDREN.find(c => c.id === selectedChild.id)?.img} className="w-full h-full object-cover" alt={selectedChild.name} />
                  </div>
                </div>
                <h3 className="text-2xl font-bold serif text-emerald-950">Sponsoring {selectedChild.name}</h3>
                <div className="flex items-center justify-center gap-2 mt-2"><div className={`w-2 h-2 rounded-full ${step === 1 ? 'bg-orange-600' : 'bg-slate-200'}`}></div><div className={`w-2 h-2 rounded-full ${step === 2 ? 'bg-orange-600' : 'bg-slate-200'}`}></div></div>
              </div>

              {step === 1 ? (
                <div className="animate-in slide-in-from-right duration-300">
                  <div className="flex justify-between items-center mb-6">
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Donor Details (Optional)</p>
                    <button onClick={() => setIsAnonymous(!isAnonymous)} className={`text-xs font-bold flex items-center gap-1.5 transition-colors ${isAnonymous ? 'text-emerald-600' : 'text-slate-400 hover:text-emerald-600'}`}><EyeOff size={14} /> {isAnonymous ? 'Anonymous On' : 'Go Anonymous'}</button>
                  </div>
                  <div className={`space-y-4 mb-8 transition-opacity ${isAnonymous ? 'opacity-30 grayscale pointer-events-none' : 'opacity-100'}`}>
                    <div className="relative"><User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} /><input type="text" placeholder="Your Name" className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all" value={donorInfo.name} onChange={(e) => setDonorInfo({...donorInfo, name: e.target.value})} disabled={isAnonymous} /></div>
                    <div className="relative"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} /><input type="email" placeholder="Email Address" className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all" value={donorInfo.email} onChange={(e) => setDonorInfo({...donorInfo, email: e.target.value})} disabled={isAnonymous} /></div>
                    <div className="relative">
                      <select 
                        className="w-full bg-slate-50 border-2 border-slate-100 rounded-xl py-3.5 pl-12 pr-4 outline-none focus:border-emerald-500 transition-all appearance-none"
                        value={donorInfo.country} 
                        onChange={(e) => setDonorInfo({...donorInfo, country: e.target.value})} 
                        disabled={isAnonymous}
                      >
                        <option value="">Select Country...</option>
                        {COUNTRIES.map(c => (
                          <option key={c.name} value={c.name}>{c.flag} {c.name}</option>
                        ))}
                      </select>
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
                        <Globe size={18} />
                      </div>
                    </div>
                  </div>
                  <button onClick={() => setStep(2)} className="w-full bg-emerald-700 hover:bg-emerald-800 text-white py-4 rounded-xl font-bold text-lg shadow-lg transition-all flex items-center justify-center gap-2">Continue to Payment <ChevronRight size={18} /></button>
                </div>
              ) : (
                <div className="animate-in slide-in-from-right duration-300">
                  <p className="text-slate-500 text-sm text-center mb-6 font-medium">Select a secure provider for your $40/mo gift:</p>
                  <div className="space-y-3 mb-8">
                    {paymentMethods.map((method) => (
                      <button key={method.id} onClick={() => setPaymentMethod(method.id)} className={`flex items-center p-4 rounded-xl border-2 transition-all gap-4 w-full text-left ${paymentMethod === method.id ? 'border-emerald-600 bg-emerald-50 text-emerald-800 shadow-sm' : 'border-slate-100 bg-slate-50 text-slate-600 hover:bg-white'}`}>
                        <div className="bg-white p-1 rounded-md shrink-0 flex items-center justify-center w-10 h-8 shadow-sm">
                           {method.icon}
                        </div>
                        <span className="font-bold text-sm tracking-wide">{method.name}</span>
                        {paymentMethod === method.id && <CheckCircle2 className="ml-auto text-emerald-600" size={18} />}
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => setStep(1)} className="flex-1 bg-slate-100 text-slate-600 py-4 rounded-xl font-bold flex items-center justify-center gap-2"><ChevronLeft size={18} /> Back</button>
                    <button onClick={handleSponsorshipPayment} disabled={!paymentMethod} className="flex-[2] bg-orange-600 hover:bg-orange-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg transition-all disabled:opacity-50">Confirm & Pay</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {isRedirecting && (
        <div className="fixed inset-0 z-[110] bg-white/95 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-500 text-center px-6">
          <div className="space-y-6 max-w-sm">
            <Loader2 className="w-16 h-16 text-emerald-600 animate-spin mx-auto" />
            <h2 className="text-2xl font-bold serif text-emerald-950">Handing Off to {selectedMethodObj?.name}</h2>
            <p className="text-slate-500">Connecting to a secure server. Your monthly gift of hope is being processed.</p>
            <div className="flex items-center justify-center gap-2 text-[10px] uppercase tracking-widest font-bold text-slate-400"><ShieldCheck size={14} /> Official Verified Gateway</div>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 md:px-6">
        <SectionHeader title="Meet the Children of Gashora" subtitle="Choose a child to sponsor and start a lifelong journey of transformation." />
        <div className="max-w-4xl mx-auto bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col md:flex-row gap-4 mb-16">
          <div className="flex-grow relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input type="text" placeholder="Search by name..." className="w-full pl-12 pr-4 py-3 bg-slate-50 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
          <button className="flex items-center justify-center gap-2 px-6 py-3 bg-slate-100 rounded-xl font-bold text-slate-700 hover:bg-slate-200 transition-all"><Filter size={20} /> Filters</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {CHILDREN.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase())).map((child) => (
            <div key={child.id} className="bg-white rounded-[2.5rem] overflow-hidden shadow-lg border border-slate-100 group">
              <div className="aspect-[4/5] relative overflow-hidden bg-slate-100">
                <img src={child.img} alt={child.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md p-2 rounded-full text-orange-600 shadow-lg"><Heart size={20} fill="currentColor" /></div>
                <div className="absolute bottom-0 left-0 w-full p-6 bg-gradient-to-t from-black/80 via-black/20 to-transparent text-white">
                  <h3 className="text-3xl font-bold serif">{child.name}, {child.age}</h3>
                  <p className="text-emerald-100 text-sm font-medium uppercase tracking-widest mt-1">Aspiring {child.dream}</p>
                </div>
              </div>
              <div className="p-8">
                <p className="text-slate-600 mb-6 leading-relaxed line-clamp-2">{child.name} is a bright and energetic {child.age}-year-old. By sponsoring {child.gender === 'Boy' ? 'him' : 'her'}, you provide daily nutrition and schooling.</p>
                <button onClick={() => setSelectedChild({name: child.name, id: child.id})} className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-xl font-bold text-center block transition-all shadow-md transform hover:scale-[1.02] flex items-center justify-center gap-2">Sponsor {child.name} Today</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SponsorChild;
