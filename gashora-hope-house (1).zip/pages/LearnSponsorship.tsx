
import React from 'react';
import SectionHeader from '../components/SectionHeader';
import { ClipboardList, Mail, RefreshCw, CheckCircle, Heart, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const LearnSponsorship: React.FC = () => {
  const steps = [
    {
      icon: <ClipboardList size={32} />,
      title: 'Choose Your Child',
      desc: 'Browse our gallery of children from Gashora Village and select one who touches your heart.'
    },
    {
      icon: <Mail size={32} />,
      title: 'Make a Connection',
      desc: 'Once you start your $40/month sponsorship, you will receive a welcome pack with your child’s photo and story.'
    },
    {
      icon: <RefreshCw size={32} />,
      title: 'See the Change',
      desc: 'Receive regular letters, school progress reports, and photos showing how your support is changing their life.'
    }
  ];

  return (
    <div className="pt-32 pb-24 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeader 
          title="How Sponsorship Works" 
          subtitle="Starting a sponsorship is the beginning of a meaningful relationship. Here is what you can expect when you join our family."
        />

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mt-16">
          {steps.map((step, i) => (
            <div key={i} className="text-center relative">
              {i < 2 && (
                <div className="hidden md:block absolute top-12 left-full w-full h-0.5 bg-emerald-100 -translate-x-12 z-0"></div>
              )}
              <div className="w-24 h-24 bg-emerald-50 text-emerald-700 rounded-3xl flex items-center justify-center mx-auto mb-8 relative z-10 shadow-sm border border-emerald-100">
                {step.icon}
              </div>
              <h3 className="text-2xl font-bold serif text-emerald-950 mb-4">{step.title}</h3>
              <p className="text-slate-600 leading-relaxed max-w-xs mx-auto">{step.desc}</p>
            </div>
          ))}
        </div>

        {/* Impact Table */}
        <div className="mt-24 bg-slate-50 rounded-[3rem] p-10 md:p-16 border border-slate-200">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-3xl font-bold serif text-emerald-900 text-center mb-12">Your $40 Monthly Gift Provides:</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                '3 Nutritious Meals Daily',
                'Full School Tuition & Uniforms',
                'Comprehensive Healthcare',
                'School Supplies & Books',
                'A Safe & Loving Home Environment',
                'Emotional & Counseling Support',
                'Access to Clean Water',
                'Life Skills & Vocational Training'
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-4 bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                  <CheckCircle className="text-emerald-500 shrink-0" size={24} />
                  <span className="font-medium text-slate-700">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* FAQ Preview */}
        <div className="mt-24 max-w-4xl mx-auto">
          <h3 className="text-3xl font-bold serif text-emerald-950 text-center mb-12">Frequently Asked Questions</h3>
          <div className="space-y-6">
            <details className="group bg-white rounded-2xl border border-slate-100 shadow-sm p-6 cursor-pointer open:bg-emerald-50/30 transition-all">
              <summary className="font-bold text-lg text-emerald-950 list-none flex justify-between items-center">
                Can I write letters to my sponsored child?
                <span className="text-emerald-500 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="mt-4 text-slate-600 leading-relaxed">
                Absolutely! We encourage communication. You can send digital letters or physical ones. Our staff will help translate them for children who don't yet speak English, and the children love replying with drawings and stories.
              </p>
            </details>
            <details className="group bg-white rounded-2xl border border-slate-100 shadow-sm p-6 cursor-pointer open:bg-emerald-50/30 transition-all">
              <summary className="font-bold text-lg text-emerald-950 list-none flex justify-between items-center">
                How long does a sponsorship last?
                <span className="text-emerald-500 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="mt-4 text-slate-600 leading-relaxed">
                Our goal is to support the children until they complete their education or vocational training and are ready for independent living. However, you can cancel your sponsorship at any time if your circumstances change.
              </p>
            </details>
            <details className="group bg-white rounded-2xl border border-slate-100 shadow-sm p-6 cursor-pointer open:bg-emerald-50/30 transition-all">
              <summary className="font-bold text-lg text-emerald-950 list-none flex justify-between items-center">
                Can I visit Gashora Hope House?
                <span className="text-emerald-500 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <p className="mt-4 text-slate-600 leading-relaxed">
                Yes! We love welcoming sponsors to Gashora. Please coordinate with us at least 3 months in advance so we can prepare for your visit and ensure a safe, positive experience for the children.
              </p>
            </details>
          </div>
        </div>

        {/* Final CTA */}
        <div className="mt-24 text-center">
          <div className="inline-block bg-orange-50 p-4 rounded-3xl mb-8">
            <Heart size={40} className="text-orange-600" fill="currentColor" />
          </div>
          <h2 className="text-4xl font-bold serif text-emerald-950 mb-6">Ready to change a life?</h2>
          <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto">
            Your sponsorship is more than a donation; it's a message of love to a child who needs to know they are valued.
          </p>
          <Link to="/sponsor-a-child" className="bg-emerald-600 hover:bg-emerald-700 text-white px-12 py-5 rounded-2xl font-bold text-xl inline-flex items-center gap-4 transition-all shadow-xl hover:-translate-y-1">
            Start Your Sponsorship <ArrowRight />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default LearnSponsorship;
