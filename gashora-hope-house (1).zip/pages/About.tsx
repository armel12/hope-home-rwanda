
import React from 'react';
import SectionHeader from '../components/SectionHeader';
import { Heart, GraduationCap, Shield, Users, Quote } from 'lucide-react';

const About: React.FC = () => {
  const values = [
    { title: 'Love', desc: 'Every child is treated with the unconditional love of a family.', icon: <Heart /> },
    { title: 'Dignity', desc: 'Restoring self-worth and pride through care and support.', icon: <Shield /> },
    { title: 'Education', desc: 'Equipping the next generation with knowledge and skills.', icon: <GraduationCap /> },
    { title: 'Community', desc: 'Working hand-in-hand with Gashora Village residents.', icon: <Users /> },
  ];

  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeader 
          title="The Story Behind the Mission" 
          subtitle="Gashora Hope House was born not from a plan, but from a calling. A journey of loss, discovery, and ultimate purpose."
        />

        {/* Founder's Personal Message Section */}
        <div className="max-w-4xl mx-auto mb-24">
          <div className="bg-white p-8 md:p-16 rounded-[3rem] shadow-2xl border border-emerald-50 relative overflow-hidden">
            <Quote className="absolute top-10 right-10 text-emerald-50 w-32 h-32 -z-0" />
            
            <div className="relative z-10 space-y-8">
              <div className="flex flex-col md:flex-row items-center gap-8 mb-8">
                <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-orange-100 shrink-0 shadow-lg bg-slate-50">
                  <img src="https://raw.githubusercontent.com/armel12/hope-home-rwanda/383cb3696555edffea9c92c58e106c2399c2a997/images/professional-portrait.png" alt="Danny Shash" className="w-full h-full object-cover" />
                </div>
                <div>
                  <h3 className="text-3xl font-bold serif text-emerald-900">A Message from Danny</h3>
                  <p className="text-orange-600 font-bold tracking-widest uppercase text-xs">Founder of Gashora Hope House</p>
                </div>
              </div>

              <div className="prose prose-lg text-slate-700 leading-relaxed font-light space-y-6 text-xl">
                <p>
                  Five years ago, I packed my life into two suitcases and made a 24-hour journey to Rwanda. I left behind everything I knew in New York to take a chance.
                </p>
                <p>
                  At that time, nothing in my life made sense anymore. After losing my brother, the world felt heavy. Rwanda gave me purpose when I thought I had lost it forever.
                </p>
                <p>
                  Today, Gashora Hope House is more than a foster home. It is a promise that every child, regardless of their past, deserves a future full of light.
                </p>
                <p className="font-bold text-emerald-900 pt-4">
                  Thank you for walking this path with us ❤️
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          {values.map((v, i) => (
            <div key={i} className="bg-emerald-50 p-8 rounded-3xl text-center border border-emerald-100 shadow-sm">
              <div className="w-12 h-12 bg-white text-emerald-700 rounded-xl flex items-center justify-center mx-auto mb-6 shadow-sm">
                {React.cloneElement(v.icon as React.ReactElement<any>, { size: 24 })}
              </div>
              <h4 className="text-xl font-bold serif text-emerald-950 mb-3">{v.title}</h4>
              <p className="text-slate-600 text-sm leading-relaxed">{v.desc}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <div className="space-y-8 text-lg text-slate-600 leading-relaxed">
            <h3 className="text-3xl font-bold serif text-emerald-950">Our Mission in Gashora</h3>
            <p>
              Located in the Bugesera District of rural Rwanda, Gashora is a community of incredible resilience. Economic hardship has left many children vulnerable, but our mission is to be the bridge to stability.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 pt-4">
              <div className="bg-white p-6 rounded-2xl shadow-md border-l-4 border-emerald-600">
                <h4 className="font-bold text-emerald-950 mb-2">Our Mission</h4>
                <p className="text-sm">To provide holistic care, education, and emotional support to orphans in Gashora.</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-md border-l-4 border-orange-600">
                <h4 className="font-bold text-emerald-950 mb-2">Our Vision</h4>
                <p className="text-sm">A Rwanda where every child grows up in a safe, loving family environment.</p>
              </div>
            </div>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-2xl aspect-video bg-slate-50">
            <img src="https://raw.githubusercontent.com/armel12/hope-home-rwanda/b40054b2b40a0832a394f7874c8d107f7cf02bea/images/fosterimage.jpg" alt="Community gathering" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
