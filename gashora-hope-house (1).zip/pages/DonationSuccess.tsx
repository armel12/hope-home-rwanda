
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { CheckCircle, Heart, ArrowRight, Share2, Mail } from 'lucide-react';

const DonationSuccess: React.FC = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const amount = searchParams.get('amount') || '50';
  const item = searchParams.get('item') || 'General Support';
  const donorName = searchParams.get('name') || 'Friend';

  return (
    <div className="pt-40 pb-24 bg-white min-h-screen">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-2xl mx-auto">
          <div className="relative inline-block mb-10">
            <div className="absolute inset-0 bg-emerald-100 rounded-full scale-150 blur-xl opacity-50 animate-pulse"></div>
            <div className="relative z-10 w-24 h-24 bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-2xl">
              <CheckCircle size={48} />
            </div>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold serif text-emerald-950 mb-6">
            Thank You, {donorName}!
          </h1>
          
          <p className="text-xl text-slate-600 mb-10 leading-relaxed font-light">
            Your generous gift of <span className="font-bold text-emerald-700">${amount}</span> for <span className="italic">"{item}"</span> has been received. Because of you, a child in Gashora has a brighter, safer tomorrow.
          </p>

          <div className="bg-slate-50 p-8 rounded-[2.5rem] border border-slate-100 mb-12 text-left">
            <h3 className="text-sm font-bold uppercase tracking-widest text-slate-400 mb-6 border-b border-slate-200 pb-2 flex items-center gap-2">
              <Heart size={14} className="text-orange-600" fill="currentColor" /> What happens next?
            </h3>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-white shadow-sm flex items-center justify-center font-bold text-emerald-700 shrink-0">1</div>
                <p className="text-slate-700">A confirmation receipt has been sent to your email address.</p>
              </li>
              <li className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-white shadow-sm flex items-center justify-center font-bold text-emerald-700 shrink-0">2</div>
                <p className="text-slate-700">Our team in Gashora is already putting your contribution to work.</p>
              </li>
              <li className="flex gap-4">
                <div className="w-8 h-8 rounded-full bg-white shadow-sm flex items-center justify-center font-bold text-emerald-700 shrink-0">3</div>
                <p className="text-slate-700">You'll receive an impact update in 3-4 weeks showing exactly how your funds were used.</p>
              </li>
            </ul>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link 
              to="/" 
              className="bg-emerald-700 hover:bg-emerald-800 text-white px-10 py-4 rounded-xl font-bold transition-all shadow-lg flex items-center justify-center gap-2"
            >
              Return Home <ArrowRight size={18} />
            </Link>
            <button 
              className="bg-white border-2 border-slate-200 text-slate-600 px-10 py-4 rounded-xl font-bold hover:bg-slate-50 transition-all flex items-center justify-center gap-2"
              onClick={() => alert("Sharing enabled for production sites.")}
            >
              <Share2 size={18} /> Share Impact
            </button>
          </div>

          <p className="mt-12 text-slate-400 text-sm flex items-center justify-center gap-2">
            <Mail size={16} /> Need help? Contact us at support@gashorahope.org
          </p>
        </div>
      </div>
    </div>
  );
};

export default DonationSuccess;
