
import React from 'react';
import { Link } from 'react-router-dom';
import SectionHeader from '../components/SectionHeader';
// Added Heart icon to imports
import { Plane, Users, Landmark, HeartHandshake, CheckCircle, Heart } from 'lucide-react';

const GetInvolved: React.FC = () => {
  return (
    <div className="pt-32 pb-24">
      <div className="container mx-auto px-4 md:px-6">
        <SectionHeader 
          title="Join the Gashora Family" 
          subtitle="There are many ways to support our mission. Whether you're across the world or across the village, we need you."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-16">
          {/* Volunteer Section */}
          <div className="bg-white p-10 rounded-[2.5rem] shadow-xl border border-slate-100 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-40 h-40 bg-orange-50 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform"></div>
            <div className="relative z-10">
              <div className="w-16 h-16 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center mb-8">
                <Plane size={32} />
              </div>
              <h3 className="text-3xl font-bold serif text-emerald-950 mb-4">Volunteer With Us</h3>
              <p className="text-slate-600 mb-8 leading-relaxed">
                We welcome local and international volunteers who are passionate about childcare, education, healthcare, and infrastructure. Whether for a week or a month, your skills can leave a lasting impact.
              </p>
              <ul className="space-y-4 mb-10">
                {[
                  'Teach English or creative arts',
                  'Assist with healthcare clinics',
                  'Support our organic garden',
                  'Help with building & maintenance'
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-slate-700">
                    <CheckCircle className="text-emerald-500" size={18} /> {item}
                  </li>
                ))}
              </ul>
              <Link to="/volunteer-application" className="inline-block bg-orange-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-orange-700 transition-all shadow-md">
                Apply to Volunteer
              </Link>
            </div>
          </div>

          {/* Partner Section */}
          <div className="bg-emerald-900 text-white p-10 rounded-[2.5rem] shadow-xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-40 h-40 bg-emerald-800 rounded-full -translate-y-1/2 translate-x-1/2 group-hover:scale-110 transition-transform"></div>
            <div className="relative z-10">
              <div className="w-16 h-16 bg-emerald-800 text-orange-400 rounded-2xl flex items-center justify-center mb-8">
                <HeartHandshake size={32} />
              </div>
              <h3 className="text-3xl font-bold serif mb-4">Partner With Us</h3>
              <p className="text-emerald-50/70 mb-8 leading-relaxed">
                We collaborate with NGOs, churches, schools, and corporate sponsors to expand our reach. Partnerships allow us to launch new facilities and scale our nutritional outreach.
              </p>
              <div className="grid grid-cols-2 gap-4 mb-10">
                <div className="p-4 bg-emerald-800/50 rounded-2xl border border-emerald-700 text-center">
                  <Users className="mx-auto mb-2 text-orange-400" />
                  <span className="text-xs font-bold uppercase tracking-widest">Corporate</span>
                </div>
                <div className="p-4 bg-emerald-800/50 rounded-2xl border border-emerald-700 text-center">
                  <Landmark className="mx-auto mb-2 text-orange-400" />
                  <span className="text-xs font-bold uppercase tracking-widest">NGOs</span>
                </div>
              </div>
              <Link to="/partnership-inquiry" className="inline-block bg-white text-emerald-900 px-8 py-3 rounded-xl font-bold hover:bg-emerald-50 transition-all shadow-md">
                Inquire About Partnership
              </Link>
            </div>
          </div>
        </div>

        {/* Sponsor a Child CTA */}
        <div className="mt-24 bg-white rounded-[3rem] p-12 md:p-20 text-center shadow-2xl relative overflow-hidden border border-emerald-50">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
          <div className="relative z-10 max-w-3xl mx-auto">
            <Heart size={64} className="text-orange-600 mx-auto mb-8 animate-pulse" />
            <h2 className="text-4xl md:text-5xl font-bold serif text-emerald-950 mb-6">Sponsor a Child</h2>
            <p className="text-xl text-slate-600 mb-10 leading-relaxed">
              For just $40 a month, you can provide comprehensive care for one child—including food, education, clothing, and healthcare. You will receive regular updates and letters from your sponsored child.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link 
                to="/sponsor-a-child" 
                className="bg-emerald-600 text-white px-10 py-4 rounded-xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-xl"
              >
                Become a Sponsor
              </Link>
              <Link 
                to="/how-sponsorship-works" 
                className="bg-slate-100 text-slate-700 px-10 py-4 rounded-xl font-bold text-lg hover:bg-slate-200 transition-all"
              >
                Learn How it Works
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetInvolved;
