
import React, { useState } from 'react';
import SectionHeader from '../components/SectionHeader';
import { Send, Calendar, Star, Info, CheckCircle2, Globe } from 'lucide-react';
import { COUNTRIES } from '../data';

const VolunteerApplication: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (submitted) {
    return (
      <div className="pt-32 pb-24 flex items-center justify-center min-h-[70vh]">
        <div className="max-w-xl w-full mx-4 bg-white p-12 rounded-[3rem] shadow-2xl text-center animate-in zoom-in duration-500">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle2 size={48} />
          </div>
          <h2 className="text-4xl font-bold serif text-emerald-950 mb-4">Application Received!</h2>
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            Thank you for wanting to share your heart with the children of Gashora. Mama Danny and our team will review your application and get back to you within 3-5 business days.
          </p>
          <button 
            onClick={() => setSubmitted(false)}
            className="bg-emerald-600 text-white px-10 py-4 rounded-xl font-bold hover:bg-emerald-700 transition-all"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 bg-[#fdfbf7]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <SectionHeader 
            title="Volunteer Application" 
            subtitle="Join our community in Rwanda. Tell us about yourself, your skills, and why you'd like to support the children of Gashora."
          />

          <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-slate-100">
            <div className="grid grid-cols-1 lg:grid-cols-5">
              {/* Sidebar Info */}
              <div className="lg:col-span-2 bg-emerald-900 text-white p-10 space-y-8">
                <div>
                  <h4 className="text-xl font-bold serif mb-4 flex items-center gap-2">
                    <Star className="text-orange-400" size={20} /> What we look for
                  </h4>
                  <p className="text-emerald-100/70 text-sm leading-relaxed">
                    We value humility, resilience, and a genuine love for children. No specific degree is required, but skills in education, health, agriculture, or maintenance are highly appreciated.
                  </p>
                </div>
                <div>
                  <h4 className="text-xl font-bold serif mb-4 flex items-center gap-2">
                    <Calendar className="text-orange-400" size={20} /> Commitment
                  </h4>
                  <p className="text-emerald-100/70 text-sm leading-relaxed">
                    Most volunteers stay between 2 weeks to 3 months. We provide guidance on local accommodation and transport in Bugesera.
                  </p>
                </div>
                <div className="p-6 bg-emerald-800/50 rounded-2xl border border-emerald-700">
                  <div className="flex gap-3 text-orange-400 mb-3">
                    <Info size={20} />
                    <span className="font-bold text-sm uppercase">Note</span>
                  </div>
                  <p className="text-xs text-emerald-100/80 leading-relaxed">
                    All volunteers are required to provide a background check and agree to our child protection policy.
                  </p>
                </div>
              </div>

              {/* Form Area */}
              <div className="lg:col-span-3 p-8 md:p-12">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Full Name</label>
                      <input required type="text" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 px-5 outline-none focus:border-emerald-500 transition-all" placeholder="Sarah Jenkins" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Email Address</label>
                      <input required type="email" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 px-5 outline-none focus:border-emerald-500 transition-all" placeholder="sarah@example.com" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Country of Residence</label>
                      <div className="relative">
                        <select 
                          required 
                          className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 px-5 outline-none focus:border-emerald-500 transition-all appearance-none"
                        >
                          <option value="">Select Country...</option>
                          {COUNTRIES.map(c => (
                            <option key={c.name} value={c.name}>{c.flag} {c.name}</option>
                          ))}
                        </select>
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                          <Globe size={18} />
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Primary Skill / Area</label>
                      <select required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 px-5 outline-none focus:border-emerald-500 transition-all">
                        <option value="">Select Skills...</option>
                        <option>Teaching / Education</option>
                        <option>Healthcare / Nursing</option>
                        <option>Agriculture / Gardening</option>
                        <option>Construction / Maintenance</option>
                        <option>Creative Arts / Music</option>
                        <option>General Support</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Preferred Dates / Duration</label>
                    <input required type="text" className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 px-5 outline-none focus:border-emerald-500 transition-all" placeholder="e.g. July 2024 for 3 weeks" />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-slate-500 ml-1">Why do you want to volunteer at Gashora?</label>
                    <textarea required rows={4} className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl py-3 px-5 outline-none focus:border-emerald-500 transition-all resize-none" placeholder="Tell us your motivation..."></textarea>
                  </div>

                  <button 
                    type="submit" 
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-bold text-lg shadow-xl transition-all flex items-center justify-center gap-3"
                  >
                    <Send size={18} /> Submit Application
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VolunteerApplication;
