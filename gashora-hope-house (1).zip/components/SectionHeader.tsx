
import React from 'react';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  centered?: boolean;
  light?: boolean;
}

const SectionHeader: React.FC<SectionHeaderProps> = ({ title, subtitle, centered = true, light = false }) => {
  return (
    <div className={`mb-12 ${centered ? 'text-center max-w-2xl mx-auto' : 'text-left max-w-xl'}`}>
      <h2 className={`text-3xl md:text-4xl lg:text-5xl font-bold mb-4 serif ${light ? 'text-white' : 'text-slate-900'}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`text-lg leading-relaxed ${light ? 'text-emerald-100/80' : 'text-slate-600'}`}>
          {subtitle}
        </p>
      )}
      <div className={`h-1.5 w-24 bg-orange-600 mt-6 rounded-full ${centered ? 'mx-auto' : 'ml-0'}`}></div>
    </div>
  );
};

export default SectionHeader;
