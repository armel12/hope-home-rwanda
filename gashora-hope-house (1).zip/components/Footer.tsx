
import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Youtube, Instagram, Facebook, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-emerald-950 text-emerald-50 pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center gap-2">
              <Heart size={28} fill="currentColor" className="text-orange-500" />
              <span className="text-2xl font-bold serif text-white">Gashora Hope House</span>
            </Link>
            <p className="text-emerald-200/80 leading-relaxed">
              Providing shelter, love, and education to vulnerable children in rural Rwanda. Together, we can build a future full of hope.
            </p>
            <div className="flex gap-4">
              <a href="https://www.youtube.com/@danni_shash" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-emerald-900 flex items-center justify-center hover:bg-orange-600 transition-colors" title="YouTube">
                <Youtube size={20} />
              </a>
              <a href="https://www.instagram.com/danni_shash/?hl=en" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-emerald-900 flex items-center justify-center hover:bg-orange-600 transition-colors" title="Instagram">
                <Instagram size={20} />
              </a>
              <a href="https://www.facebook.com/danni.shash/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-emerald-900 flex items-center justify-center hover:bg-orange-600 transition-colors" title="Facebook">
                <Facebook size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white text-lg font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><Link to="/about" className="hover:text-orange-400 transition-colors">About Our Center</Link></li>
              <li><Link to="/founder" className="hover:text-orange-400 transition-colors">Danny's Story</Link></li>
              <li><Link to="/programs" className="hover:text-orange-400 transition-colors">Our Programs</Link></li>
              <li><Link to="/get-involved" className="hover:text-orange-400 transition-colors">How to Help</Link></li>
              <li><Link to="/gallery" className="hover:text-orange-400 transition-colors">Media Gallery</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white text-lg font-bold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="text-orange-500 shrink-0 mt-1" size={18} />
                <span>Gashora Village, Bugesera District, Rwanda</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="text-orange-500 shrink-0" size={18} />
                <span>+250 7XX XXX XXX</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="text-orange-500 shrink-0" size={18} />
                <span>hello@gashorahope.org</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white text-lg font-bold mb-6">Join Our Newsletter</h4>
            <p className="text-sm text-emerald-200/80 mb-4">Stay updated with stories of transformation from Gashora.</p>
            <form className="space-y-2" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Your email address" 
                className="w-full bg-emerald-900 border-none rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-orange-500"
              />
              <button className="w-full bg-orange-600 hover:bg-orange-700 py-3 rounded-lg font-bold transition-colors">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="pt-8 border-t border-emerald-900 text-center text-sm text-emerald-200/50">
          <p>© {new Date().getFullYear()} Gashora Hope House. All Rights Reserved.</p>
          <p className="mt-2">Registered Non-Profit Organization in Rwanda.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
