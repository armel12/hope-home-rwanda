
export interface Program {
  id: string;
  title: string;
  description: string;
  icon: string;
  image: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  image: string;
}

export interface ImpactStat {
  label: string;
  value: string;
  suffix?: string;
}
