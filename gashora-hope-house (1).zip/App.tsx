
import React, { useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import FounderStory from './pages/FounderStory';
import Programs from './pages/Programs';
import ProgramDetail from './pages/ProgramDetail';
import Gallery from './pages/Gallery';
import GetInvolved from './pages/GetInvolved';
import Donate from './pages/Donate';
import Contact from './pages/Contact';
import SponsorChild from './pages/SponsorChild';
import LearnSponsorship from './pages/LearnSponsorship';
import VolunteerApplication from './pages/VolunteerApplication';
import PartnershipInquiry from './pages/PartnershipInquiry';
import DonationSuccess from './pages/DonationSuccess';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  return (
    <Router>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/founder" element={<FounderStory />} />
            <Route path="/programs" element={<Programs />} />
            <Route path="/programs/:programId" element={<ProgramDetail />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/get-involved" element={<GetInvolved />} />
            <Route path="/donate" element={<Donate />} />
            <Route path="/donation-success" element={<DonationSuccess />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/sponsor-a-child" element={<SponsorChild />} />
            <Route path="/how-sponsorship-works" element={<LearnSponsorship />} />
            <Route path="/volunteer-application" element={<VolunteerApplication />} />
            <Route path="/partnership-inquiry" element={<PartnershipInquiry />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

export default App;
